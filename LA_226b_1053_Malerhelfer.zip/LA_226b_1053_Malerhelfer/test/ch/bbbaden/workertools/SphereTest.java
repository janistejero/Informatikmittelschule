/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.workertools;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Janis Tejero
 */
public class SphereTest {

    public SphereTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getSurfaceArea method, of class Sphere.
     */
    @Test
    public void testGetSurfaceArea1() {

        //Arrange
        System.out.println("getSurfaceAreaSphere1");
        Sphere instance = new Sphere(5);
        double expResult = Math.PI * 100;
        //Act
        double result = instance.getSurfaceArea();
        //Assert
        assertEquals(expResult, result, 0.001);
        System.out.println(result);
    }

    @Test
    public void testGetSurfaceArea2() {

        //Arrange
        System.out.println("getSurfaceAreaSphere2");
        Sphere instance = new Sphere(20.56);
        double expResult = 5311.975761;
        //Act
        double result = instance.getSurfaceArea();
        //Assert
        assertEquals(expResult, result, 0.000001);
        System.out.println(result + "\n");
    }

}
