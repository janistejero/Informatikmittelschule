/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.workertools;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Janis Tejero
 */
public class PaintTest {

    public PaintTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getBucketsNeeded method, of class Paint.
     */
    @Test
    public void testGetBucketsNeeded1() {
        System.out.println("getBucketsNeeded");
        //Arrange
        Paint instance = new Paint(0.5, 4);

        PaintStructure ps = new PaintStructure();
        ps.addShape(new Cube(1));
        ps.addShape(new Conoid(3, 5));
        ps.addShape(new Sphere(2));
        ps.addShape(new Cuboid(1, 4, 2));
        int expResult = 21;
        //Act
        int result = instance.getBucketsNeeded(ps);
        //Assert
        assertEquals(expResult, result);
        System.out.println(result);
    }

    @Test
    public void testGetBucketsNeeded2() {
        System.out.println("getBucketsNeeded");
        //Arrange
        Paint instance = new Paint(1, 3);

        PaintStructure ps = new PaintStructure();
        ps.addShape(new Cube(1));
        ps.addShape(new Conoid(3, 5));
        ps.addShape(new Sphere(2));
        ps.addShape(new Cuboid(1, 4, 2));
        int expResult = 56;
        //Act
        int result = instance.getBucketsNeeded(ps);
        //Assert
        assertEquals(expResult, result);
        System.out.println(result + "\n");
    }

}
