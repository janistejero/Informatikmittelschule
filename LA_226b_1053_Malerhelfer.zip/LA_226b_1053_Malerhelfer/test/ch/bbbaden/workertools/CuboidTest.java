/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.workertools;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Janis Tejero
 */
public class CuboidTest {
    
    public CuboidTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getSurfaceArea method, of class Cuboid.
     */
    @Test
    public void testGetSurfaceArea1() {
        
        //Arrange
        System.out.println("getSurfaceAreaCuboid1");
        Cuboid instance = new Cuboid(1, 2, 3);
        double expResult = 22;
        //Act
        double result = instance.getSurfaceArea();
        //Assert
        assertEquals(expResult, result, 0.001);
        System.out.println(result);
    }
    
    @Test
    public void testGetSurfaceArea2() {
        
        //Arrange
        System.out.println("getSurfaceAreaCuboid2");
        Cuboid instance = new Cuboid(2.5, 5.25, 8.1);
        double expResult = 151.8;
        //Act
        double result = instance.getSurfaceArea();
        //Assert
        assertEquals(expResult, result, 0.001);
        System.out.println(result + "\n");
    }
    
}
