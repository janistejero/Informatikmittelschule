/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.workertools;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Janis Tejero
 */
public class ConoidTest {
    
    public ConoidTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getSurfaceArea method, of class Conoid.
     */
    @Test
    public void testGetSurfaceArea1() {
        
        //Arrange
        System.out.println("getSurfaceAreaConoid1");
        Conoid instance = new Conoid(5, 10);
        double expResult = 254.160;
        //Act
        double result = instance.getSurfaceArea();
        //Assert
        assertEquals(expResult, result, 0.001);
        System.out.println(result);
    }
    
    @Test
    public void testGetSurfaceArea2() {
        
        //Arrange
        System.out.println("getSurfaceAreaConoid2");
        Conoid instance = new Conoid(10, 20);
        double expResult = 1016.640;
        //Act
        double result = instance.getSurfaceArea();
        //Assert
        assertEquals(expResult, result, 0.001);
        System.out.println(result + "\n");
    }
    
}
