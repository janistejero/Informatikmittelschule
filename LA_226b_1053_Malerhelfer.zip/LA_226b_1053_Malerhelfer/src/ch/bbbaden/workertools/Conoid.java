/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.workertools;

/**
 *
 * @author Janis Tejero
 */
public class Conoid extends Shape{
    
    private final double radius;
    private final double height;
    
    public Conoid(double radius, double height){
        this.radius = radius;
        this.height = height;
    }
    
    @Override
    public double getSurfaceArea(){
        double s = Math.sqrt((radius * radius) + (height * height));
        
        return Math.PI * (radius * radius) + (Math.PI * radius * s);
    }
}
