/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.workertools;

/**
 *
 * @author Janis Tejero
 */
public class Paint {
    
    private final double literPerSquareMeter;
    private final double literPerBucket;
    
    public Paint(double literPerSquareMeter, double literPerBucket){
        this.literPerSquareMeter = literPerSquareMeter;
        this.literPerBucket = literPerBucket;
    }
    
    public int getBucketsNeeded(PaintStructure paintStructure){
        double amountOfLitres; 
        amountOfLitres = (paintStructure.getCompleteSurfaceArea() * literPerSquareMeter) / literPerBucket;
        return (int)Math.ceil(amountOfLitres);
    }
}
