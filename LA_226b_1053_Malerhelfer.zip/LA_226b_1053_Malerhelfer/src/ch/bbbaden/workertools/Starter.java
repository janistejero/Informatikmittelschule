/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.workertools;


/**
 *
 * @author Janis Tejero
 */
public class Starter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Paint paint = new Paint(1, 3);

        PaintStructure ps = new PaintStructure();
        ps.addShape(new Cube(1));
        ps.addShape(new Conoid(3, 5));
        ps.addShape(new Sphere(2));
        ps.addShape(new Cuboid(1, 4, 2));

        System.out.println(paint.getBucketsNeeded(ps) + " Eimer sind gefragt");
    }

}
