/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.workertools;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Janis Tejero
 */
public class PaintStructure {

    private final List<Shape> shapes = new ArrayList<>();

    public double getCompleteSurfaceArea() {

        double total = 0;

        for (Shape shape : shapes) {
            total += shape.getSurfaceArea();
        }
        return total;
    }

    public void addShape(Shape shape) {
        shapes.add(shape);
    }
}
